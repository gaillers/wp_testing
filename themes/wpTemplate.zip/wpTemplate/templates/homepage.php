<?php

/**
 * Template Name: Homepage
 *
 * @package WordPress
 * @subpackage Template
 * @since Template
 */
get_header();

?>
<main class="site-main">


</main>


<?php

get_footer();