<?php
/**
* Template Name: Some Page
*
* @package WordPress
* @subpackage Template
* @since Template
*/
get_header();

?>


<?php

get_footer();
