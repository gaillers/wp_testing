# Default theme for new projects
git clone https://github.com/hereWasKitus/wordpress-default-theme.git .; rm -rf trunk .gitignore readme.md .git
